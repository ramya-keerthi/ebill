package com.Ebill.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Ebill.Service.EbillService;
import com.Ebill.Service.IEbillService;
import com.Ebill.bean.Consumerdetails;
import com.Ebill.bean.Ebillbean;

/**
 * Servlet implementation class Servletcontroller
 */
@WebServlet("/Servletcontroller")
public class Servletcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servletcontroller() {
        super();
       
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String option=request.getParameter("action");
		if(option.equals("login"))
		{
			if(request.getParameter("username").equals("admin")&& request.getParameter("password").equals("admin"))
			{
				getServletContext().getRequestDispatcher("/ebill.html").forward(request,response);
			}
		}
		else if(option.equals("CalculateBill"))
		{int consumerNumber=Integer.parseInt(request.getParameter("consumernumber"));
		float lastMonMeterRead=Float.parseFloat(request.getParameter("Lmmr"));
		float currentMonMeterRead=Float.parseFloat(request.getParameter("Cmmr"));
		final float FIXEDCHARGES=100f; 
		float units,netamount;
		IEbillService ibill=new EbillService();
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		Consumerdetails cons=ibill.validateConsumernum(consumerNumber);
		if(cons!=null)
		{	
			if(currentMonMeterRead<lastMonMeterRead)
				out.println("Invalid Meter Reading");
			else
				{
					units=(currentMonMeterRead-lastMonMeterRead);
					netamount=(units*1.15f+FIXEDCHARGES);
				Ebillbean bill=new Ebillbean();
					bill.setConsumernumber(cons.getConsumernumber());
					bill.setCmmr(currentMonMeterRead);
					bill.setUnits(units);
					bill.setNetamount(netamount);
					
					try {
						ibill.addEbillDetails(bill);
					} catch (SQLException e) {
						
						e.printStackTrace();
					}
					/*request.setAttribute("bill",bill);
					request.setAttribute("consumer",cons);*/
					out.println("Welcome "+cons.getConsumername());
					out.println("<br/><h2>Electricity Bill For Consumer Number - "+bill.getConsumernumber()+"is<br/>");
					out.print("Units Consumed:: "+bill.getUnits());
					out.print("Net Amount::Rs. "+bill.getNetamount());
				}
		}
		 else{
			out.println("Invalid Consumer Number");
		}
			
		}
	}

}
