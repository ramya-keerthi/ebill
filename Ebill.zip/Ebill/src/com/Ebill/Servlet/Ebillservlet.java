package com.Ebill.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
//import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Ebill.bean.Ebillbean;

/**
 * Servlet implementation class Ebillservlet
 */
@WebServlet("/Ebillservlet")
public class Ebillservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Ebillservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/plain");
		    PrintWriter out = response.getWriter();
		    int Consumernumber =Integer.parseInt( request.getParameter("Consumernumber"));
		    String Lmmr= request.getParameter("Lmmr");
			float lastmonthmr = Float.parseFloat(request.getParameter(Lmmr));
			 String Cmmr= request.getParameter("Cmmr");
				float Currentmonthmr = Float.parseFloat(request.getParameter(Cmmr));
			
			Ebillbean bill=new Ebillbean();
		    bill.setConsumernumber(Consumernumber);
		    bill.setLmmr(lastmonthmr);
			bill.setCmmr(Currentmonthmr);
			request.setAttribute("Ebillbean",bill);
				
			out.println("this is printed as include statement is used ");
		    
		    
		    
	}

}












