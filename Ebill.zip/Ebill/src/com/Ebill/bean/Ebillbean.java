package com.Ebill.bean;

public class Ebillbean {
	int consumernumber;
	float Lmmr;
	float Cmmr;
	int EbillId;
	private float units;
	 private float netamount;
	
	public float getNetamount() {
		return netamount;
	}
	public void setNetamount(float netamount) {
		this.netamount = netamount;
	}
	public float getUnits() {
		return units;
	}
	public void setUnits(float units) {
		this.units = units;
	}
	
	public static final int fixedcharge=100;
	public int getEbillId() {
		return EbillId;
	}
	public void setEbillId(int ebillId) {
		EbillId = ebillId;
	}
	public int getConsumernumber() {
		return consumernumber;
	}
	public void setConsumernumber(int consumernumber) {
		this.consumernumber = consumernumber;
	}
	public float getLmmr() {
		return Lmmr;
	}
	public void setLmmr(float lastmonthmr) {
		Lmmr = lastmonthmr;
	}
	public float getCmmr() {
		return Cmmr;
	}
	public void setCmmr(float currentmonthmr) {
		Cmmr = currentmonthmr;
	}
	
}