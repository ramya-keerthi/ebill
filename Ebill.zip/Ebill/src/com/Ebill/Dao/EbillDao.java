package com.Ebill.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.Ebill.bean.Consumerdetails;
import com.Ebill.bean.Ebillbean;
import com.Ebill.util.DBconnection;

public class EbillDao implements IEbillDao {

	@Override
	public void addEbillDetails(Ebillbean bill) throws SQLException {
	try{
		Connection conn=DBconnection.getConnection();
		PreparedStatement preparedstatement=conn.prepareStatement(IqueryMapper.INSERTBILLDETAILS);
		preparedstatement.setInt(1,bill.getConsumernumber());
		preparedstatement.setFloat(2,bill.getLmmr());
		preparedstatement.setFloat(3,bill.getCmmr());
		preparedstatement.setInt(4,bill.getEbillId());
		preparedstatement.setFloat(5,bill.getUnits());
		preparedstatement.setFloat(6,bill.getNetamount());
		preparedstatement.executeUpdate();
	}catch(SQLException se)
	{
		
	}

	
	}

	@Override
	public Consumerdetails validateConsumernum(int Consumernumber) {
		Consumerdetails consumer=null;
		try{
			Connection conn=DBconnection.getConnection();
			PreparedStatement preparedstatement=conn.prepareStatement(IqueryMapper.GETCONSUMERDETAILS );
			preparedstatement.setInt(1,Consumernumber);
			ResultSet result=preparedstatement.executeQuery();
			result.next();
			if(result.getString(1)!=null)
			{
			consumer=new Consumerdetails();
			System.out.println(Consumernumber);
			consumer.setConsumernumber(Consumernumber);
			consumer.setConsumername(result.getString(1));
			consumer.setAddress(result.getString(2));
			return consumer;
			}
}
	catch(SQLException se)
	{
		
	}
	return consumer;
		}
		
	}

	
