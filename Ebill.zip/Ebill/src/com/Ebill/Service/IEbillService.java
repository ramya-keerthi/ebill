package com.Ebill.Service;

import java.sql.SQLException;

import com.Ebill.bean.Consumerdetails;
import com.Ebill.bean.Ebillbean;

public interface IEbillService {
	 void addEbillDetails(Ebillbean bill) throws SQLException;
	
	Consumerdetails validateConsumernum(int Consumernumber);

}
