package com.Ebill.Dao;

public interface IqueryMapper {
	static final String GETCONSUMERDETAILS = "SELECT consumer_name,address FROM consumers where consumer_num=?";
	static final String INSERTBILLDETAILS = "INSERT INTO billdetails values(bill_seq.nextval,?,?,?,?,?,SYSDATE)";
}
