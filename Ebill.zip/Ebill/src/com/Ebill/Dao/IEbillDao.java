package com.Ebill.Dao;

import java.sql.SQLException;

import com.Ebill.bean.Consumerdetails;
import com.Ebill.bean.Ebillbean;

public interface IEbillDao {
  void addEbillDetails(Ebillbean bill) throws SQLException;
	
	Consumerdetails validateConsumernum(int Consumernumber);

	


}
