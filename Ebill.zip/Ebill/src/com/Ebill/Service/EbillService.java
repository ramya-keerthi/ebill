package com.Ebill.Service;

import java.sql.SQLException;

import com.Ebill.Dao.EbillDao;
import com.Ebill.Dao.IEbillDao;
import com.Ebill.bean.Consumerdetails;
import com.Ebill.bean.Ebillbean;

public class EbillService implements IEbillService {

	@Override
	public void addEbillDetails(Ebillbean bill) throws SQLException {
		IEbillDao ebill=new EbillDao();
		 ebill.addEbillDetails(bill);
		
	
	}

	@Override
	public Consumerdetails validateConsumernum(int Consumernumber) {
		IEbillDao ebill=new EbillDao();
		return ebill.validateConsumernum(Consumernumber);
		
	}

	
}
	