package com.Ebill.bean;

public class Consumerdetails {
	int consumernumber;
	String address;
	String consumername;
	public int getConsumernumber() {
		return consumernumber;
	}
	public void setConsumernumber(int consumernumber) {
		this.consumernumber = consumernumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getConsumername() {
		return consumername;
	}
	public void setConsumername(String consumername) {
		this.consumername = consumername;
	}
	
	
}
